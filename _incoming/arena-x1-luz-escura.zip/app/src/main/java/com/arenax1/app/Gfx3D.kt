package com.arenax1.app

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

// Cada vértice: posição(3) + normal(3) + cor RGBA(4) = 10 floats.
// Normal zero = vértice sem luz (brilho próprio).

class VBuf {
    var v = FloatArray(10 * 3000)
    var n = 0
    fun need(extra: Int) {
        if (n + extra > v.size) v = v.copyOf(maxOf(v.size * 2, n + extra))
    }
}

/** Lote de geometria com pilha de matrizes. Três destinos: opaco, translúcido e aditivo. */
class Batch {
    val opq = VBuf()
    val alp = VBuf()
    val add = VBuf()

    /** 0 = automático (alpha<1 vai para translúcido), 2 = aditivo. */
    var mode = 0

    /** Lote dinâmico: limita a resolução das formas para ganhar desempenho. */
    var lod = false

    /** Fator de qualidade das formas curvas (1 = cheio). Reduz custo em objetos numerosos. */
    var dq = 1f

    private val stack = Array(40) { FloatArray(16) }
    private var sp = 0
    private val m: FloatArray get() = stack[sp]

    init {
        Matrix.setIdentityM(stack[0], 0)
    }

    fun clear() {
        opq.n = 0; alp.n = 0; add.n = 0
        sp = 0
        Matrix.setIdentityM(stack[0], 0)
        mode = 0
    }

    fun push() {
        System.arraycopy(stack[sp], 0, stack[sp + 1], 0, 16)
        sp++
    }

    fun pop() {
        sp--
    }

    fun tr(x: Float, y: Float, z: Float) = Matrix.translateM(stack[sp], 0, x, y, z)
    fun rotX(deg: Float) = Matrix.rotateM(stack[sp], 0, deg, 1f, 0f, 0f)
    fun rotY(deg: Float) = Matrix.rotateM(stack[sp], 0, deg, 0f, 1f, 0f)
    fun rotZ(deg: Float) = Matrix.rotateM(stack[sp], 0, deg, 0f, 0f, 1f)
    fun sc(x: Float, y: Float, z: Float) = Matrix.scaleM(stack[sp], 0, x, y, z)

    private fun target(a: Float): VBuf = when {
        mode == 2 -> add
        a < 0.999f -> alp
        else -> opq
    }

    private var cr = 1f
    private var cg = 1f
    private var cb = 1f
    private var ca = 1f
    private var tb: VBuf = opq

    private fun setCol(col: Int, a: Float) {
        cr = ((col shr 16) and 255) / 255f
        cg = ((col shr 8) and 255) / 255f
        cb = (col and 255) / 255f
        ca = a * (((col ushr 24) and 255) / 255f)
        tb = target(ca)
        tb.need(12000)
    }

    /** Emite um vértice transformado pela matriz atual. */
    private fun vx(px: Float, py: Float, pz: Float, nx: Float, ny: Float, nz: Float) {
        val a = m
        val b = tb
        if (b.n + 12 > b.v.size) b.need(12)
        val o = b.v
        var i = b.n
        o[i++] = a[0] * px + a[4] * py + a[8] * pz + a[12]
        o[i++] = a[1] * px + a[5] * py + a[9] * pz + a[13]
        o[i++] = a[2] * px + a[6] * py + a[10] * pz + a[14]
        if (nx == 0f && ny == 0f && nz == 0f) {
            o[i++] = 0f; o[i++] = 0f; o[i++] = 0f
        } else {
            val tx = a[0] * nx + a[4] * ny + a[8] * nz
            val ty = a[1] * nx + a[5] * ny + a[9] * nz
            val tz = a[2] * nx + a[6] * ny + a[10] * nz
            val l = sqrt(tx * tx + ty * ty + tz * tz)
            val k = if (l > 0.0001f) 1f / l else 0f
            o[i++] = tx * k; o[i++] = ty * k; o[i++] = tz * k
        }
        o[i++] = cr; o[i++] = cg; o[i++] = cb; o[i++] = ca
        b.n = i
    }

    private fun tri(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        nx: Float, ny: Float, nz: Float, lit: Boolean
    ) {
        if (lit) {
            vx(ax, ay, az, nx, ny, nz); vx(bx, by, bz, nx, ny, nz); vx(cx, cy, cz, nx, ny, nz)
        } else {
            vx(ax, ay, az, 0f, 0f, 0f); vx(bx, by, bz, 0f, 0f, 0f); vx(cx, cy, cz, 0f, 0f, 0f)
        }
    }

    private fun quad(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        dx: Float, dy: Float, dz: Float,
        nx: Float, ny: Float, nz: Float, lit: Boolean
    ) {
        tri(ax, ay, az, bx, by, bz, cx, cy, cz, nx, ny, nz, lit)
        tri(ax, ay, az, cx, cy, cz, dx, dy, dz, nx, ny, nz, lit)
    }

    /** Caixa centrada em (cx,cy,cz) com tamanho (sx,sy,sz). */
    fun box(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, col: Int, a: Float = 1f, lit: Boolean = true) {
        setCol(col, a)
        val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
        val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
        val z0 = cz - sz / 2f; val z1 = cz + sz / 2f
        quad(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0f, 1f, 0f, lit)
        quad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0f, -1f, 0f, lit)
        quad(x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 1f, 0f, 0f, lit)
        quad(x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1, -1f, 0f, 0f, lit)
        quad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0f, 0f, 1f, lit)
        quad(x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0f, 0f, -1f, lit)
    }

    /** Cilindro/cone vertical: base em y0 com raio r0, topo em y0+h com raio r1. */
    fun cyl(cx: Float, y0: Float, cz: Float, r0: Float, r1: Float, h: Float, col: Int, seg0: Int = 8, a: Float = 1f, lit: Boolean = true) {
        val sg = if (lod && seg0 > 16) 16 else seg0
        val seg = if (sg <= 6) sg else max(6, (sg * dq).toInt())
        setCol(col, a)
        val y1 = y0 + h
        val slope = (r0 - r1) / (if (h == 0f) 1f else h)
        val smooth = seg >= 7 && lit
        for (i in 0 until seg) {
            val a0 = (i.toFloat() / seg * 2f * PI).toFloat()
            val a1 = ((i + 1).toFloat() / seg * 2f * PI).toFloat()
            val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
            val am = (a0 + a1) / 2f
            val nx = cos(am); val nz = sin(am)
            val ny = slope
            if (r1 > 0.01f) {
                if (smooth) {
                    val ax = cx + c0 * r0; val az = cz + s0 * r0
                    val bx = cx + c1 * r0; val bz = cz + s1 * r0
                    val ex = cx + c1 * r1; val ez = cz + s1 * r1
                    val dx = cx + c0 * r1; val dz = cz + s0 * r1
                    vx(ax, y0, az, c0, ny, s0); vx(bx, y0, bz, c1, ny, s1); vx(ex, y1, ez, c1, ny, s1)
                    vx(ax, y0, az, c0, ny, s0); vx(ex, y1, ez, c1, ny, s1); vx(dx, y1, dz, c0, ny, s0)
                } else {
                    quad(cx + c0 * r0, y0, cz + s0 * r0, cx + c1 * r0, y0, cz + s1 * r0,
                        cx + c1 * r1, y1, cz + s1 * r1, cx + c0 * r1, y1, cz + s0 * r1, nx, ny, nz, lit)
                }
            } else {
                if (smooth) {
                    vx(cx + c0 * r0, y0, cz + s0 * r0, c0, ny, s0)
                    vx(cx + c1 * r0, y0, cz + s1 * r0, c1, ny, s1)
                    vx(cx, y1, cz, nx, ny, nz)
                } else {
                    tri(cx + c0 * r0, y0, cz + s0 * r0, cx + c1 * r0, y0, cz + s1 * r0, cx, y1, cz, nx, ny, nz, lit)
                }
            }
            if (r1 > 0.01f) tri(cx, y1, cz, cx + c0 * r1, y1, cz + s0 * r1, cx + c1 * r1, y1, cz + s1 * r1, 0f, 1f, 0f, lit)
            if (r0 > 0.01f) tri(cx, y0, cz, cx + c0 * r0, y0, cz + s0 * r0, cx + c1 * r0, y0, cz + s1 * r0, 0f, -1f, 0f, lit)
        }
    }

    /** Elipsoide centrado em (cx,cy,cz) com raios (rx,ry,rz). */
    fun sphere(cx: Float, cy: Float, cz: Float, rx: Float, ry: Float, rz: Float, col: Int, a: Float = 1f, lit: Boolean = true, sl0: Int = 8, st0: Int = 5) {
        val sl1 = if (lod && sl0 > 16) 16 else sl0
        val st1 = if (lod && st0 > 10) 10 else st0
        val sl = if (sl1 <= 5) sl1 else max(5, (sl1 * dq).toInt())
        val st = if (st1 <= 3) st1 else max(3, (st1 * dq).toInt())
        setCol(col, a)
        for (i in 0 until st) {
            val p0 = (-PI / 2.0 + PI * i / st).toFloat()
            val p1 = (-PI / 2.0 + PI * (i + 1) / st).toFloat()
            val y0 = sin(p0); val y1 = sin(p1)
            val r0 = cos(p0); val r1 = cos(p1)
            for (j in 0 until sl) {
                val t0 = (2.0 * PI * j / sl).toFloat()
                val t1 = (2.0 * PI * (j + 1) / sl).toFloat()
                val c0 = cos(t0); val s0 = sin(t0); val c1 = cos(t1); val s1 = sin(t1)
                // quatro cantos, cada um com a própria normal (esfera suave)
                val ax = r0 * c0; val ay = y0; val az = r0 * s0
                val bx = r0 * c1; val bz = r0 * s1
                val dx = r1 * c0; val dy = y1; val dz = r1 * s0
                val ex = r1 * c1; val ez = r1 * s1
                if (lit) {
                    vx(cx + ax * rx, cy + ay * ry, cz + az * rz, ax, ay, az)
                    vx(cx + bx * rx, cy + ay * ry, cz + bz * rz, bx, ay, bz)
                    vx(cx + ex * rx, cy + dy * ry, cz + ez * rz, ex, dy, ez)
                    vx(cx + ax * rx, cy + ay * ry, cz + az * rz, ax, ay, az)
                    vx(cx + ex * rx, cy + dy * ry, cz + ez * rz, ex, dy, ez)
                    vx(cx + dx * rx, cy + dy * ry, cz + dz * rz, dx, dy, dz)
                } else {
                    tri(cx + ax * rx, cy + ay * ry, cz + az * rz, cx + bx * rx, cy + ay * ry, cz + bz * rz,
                        cx + ex * rx, cy + dy * ry, cz + ez * rz, 0f, 0f, 0f, false)
                    tri(cx + ax * rx, cy + ay * ry, cz + az * rz, cx + ex * rx, cy + dy * ry, cz + ez * rz,
                        cx + dx * rx, cy + dy * ry, cz + dz * rz, 0f, 0f, 0f, false)
                }
            }
        }
    }

    /** Disco horizontal (leque de triângulos). */
    fun disc(cx: Float, y: Float, cz: Float, r: Float, col: Int, a: Float = 1f, lit: Boolean = false, seg: Int = 24) {
        setCol(col, a)
        for (i in 0 until seg) {
            val a0 = (i.toFloat() / seg * 2f * PI).toFloat()
            val a1 = ((i + 1).toFloat() / seg * 2f * PI).toFloat()
            tri(cx, y, cz, cx + cos(a0) * r, y, cz + sin(a0) * r, cx + cos(a1) * r, y, cz + sin(a1) * r, 0f, 1f, 0f, lit)
        }
    }

    /** Anel horizontal entre r0 e r1. */
    fun ring(cx: Float, y: Float, cz: Float, r0: Float, r1: Float, col: Int, a: Float = 1f, lit: Boolean = false, seg: Int = 28) {
        setCol(col, a)
        for (i in 0 until seg) {
            val a0 = (i.toFloat() / seg * 2f * PI).toFloat()
            val a1 = ((i + 1).toFloat() / seg * 2f * PI).toFloat()
            val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
            quad(cx + c0 * r0, y, cz + s0 * r0, cx + c1 * r0, y, cz + s1 * r0,
                cx + c1 * r1, y, cz + s1 * r1, cx + c0 * r1, y, cz + s0 * r1, 0f, 1f, 0f, lit)
        }
    }

    /** Triângulo cru com cor por vértice (usado no terreno, sem matriz). */
    fun rawVert(px: Float, py: Float, pz: Float, nx: Float, ny: Float, nz: Float, col: Int) {
        val b = opq
        b.need(12)
        var i = b.n
        val o = b.v
        o[i++] = px; o[i++] = py; o[i++] = pz
        o[i++] = nx; o[i++] = ny; o[i++] = nz
        o[i++] = ((col shr 16) and 255) / 255f
        o[i++] = ((col shr 8) and 255) / 255f
        o[i++] = (col and 255) / 255f
        o[i++] = 1f
        b.n = i
    }
}

fun mixCol(a: Int, b: Int, k: Float): Int {
    val kk = k.coerceIn(0f, 1f)
    val r = (((a shr 16) and 255) * (1f - kk) + ((b shr 16) and 255) * kk).toInt()
    val g = (((a shr 8) and 255) * (1f - kk) + ((b shr 8) and 255) * kk).toInt()
    val bl = ((a and 255) * (1f - kk) + (b and 255) * kk).toInt()
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
}

fun shadeCol(a: Int, k: Float): Int {
    val r = (((a shr 16) and 255) * k).toInt().coerceIn(0, 255)
    val g = (((a shr 8) and 255) * k).toInt().coerceIn(0, 255)
    val b = ((a and 255) * k).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
}

fun cc(h: Long): Int = h.toInt()

class StaticMesh(val vbo: Int, val count: Int, val x0: Float, val x1: Float)

/** Escolhe a melhor configuração EGL: MSAA e profundidade 24 se existirem. */
class MsaaChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (samples in intArrayOf(2, 0)) {
            for (depth in intArrayOf(24, 16)) {
                val spec = if (samples > 0) intArrayOf(
                    EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8,
                    EGL10.EGL_DEPTH_SIZE, depth, EGL10.EGL_RENDERABLE_TYPE, 4,
                    EGL10.EGL_SAMPLE_BUFFERS, 1, EGL10.EGL_SAMPLES, samples, EGL10.EGL_NONE
                ) else intArrayOf(
                    EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8,
                    EGL10.EGL_DEPTH_SIZE, depth, EGL10.EGL_RENDERABLE_TYPE, 4, EGL10.EGL_NONE
                )
                val num = IntArray(1)
                if (egl.eglChooseConfig(display, spec, null, 0, num) && num[0] > 0) {
                    val cfgs = arrayOfNulls<EGLConfig>(num[0])
                    egl.eglChooseConfig(display, spec, cfgs, num[0], num)
                    val c = cfgs[0]
                    if (c != null) return c
                }
            }
        }
        throw IllegalArgumentException("Nenhuma configuração EGL")
    }
}

const val SKY_R = 0.10f
const val SKY_G = 0.14f
const val SKY_B = 0.28f

class GlRenderer(private val g: GameView) : GLSurfaceView.Renderer {

    private var prog = 0
    private var uVP = 0
    private var uFog = 0
    private var uCam = 0
    private var uOut = 0
    private var uDet = 0
    private var aP = 0
    private var aN = 0
    private var aC = 0
    private var dynVbo = 0
    private var fb: FloatBuffer = ByteBuffer.allocateDirect(4 * 10 * 6000).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val statics = ArrayList<StaticMesh>()

    private val VS = """
        uniform mat4 uVP;
        uniform vec3 uCam;
        uniform float uOut;
        attribute vec3 aP;
        attribute vec3 aN;
        attribute vec4 aC;
        varying vec4 vC;
        varying float vFog;
        varying vec3 vW;
        varying float vLit;
        void main() {
            float l = length(aN);
            vW = aP;
            vLit = l > 0.5 ? 1.0 : 0.0;
            vec3 pos = aP;
            vec3 col = aC.rgb;
            if (uOut > 0.0) {
                if (l < 0.5) {
                    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
                    vC = vec4(0.0);
                    vFog = 0.0;
                    return;
                }
                float w0 = (uVP * vec4(aP, 1.0)).w;
                pos = aP + (aN / l) * uOut * (w0 / 1100.0);
                gl_Position = uVP * vec4(pos, 1.0);
                gl_Position.z += gl_Position.w * 0.004;
                vC = vec4(col * 0.22 + vec3(0.01, 0.015, 0.04), aC.a);
                vFog = clamp((gl_Position.w - 1900.0) / 3200.0, 0.0, 1.0);
                return;
            }
            gl_Position = uVP * vec4(pos, 1.0);
            if (l > 0.5) {
                vec3 n = aN / l;
                vec3 L = normalize(vec3(-0.35, 0.85, 0.40));
                vec3 V = normalize(uCam - aP);
                float ndl = dot(n, L);
                float band = smoothstep(-0.05, 0.6, ndl);
                vec3 amb = mix(vec3(0.20, 0.24, 0.40), vec3(0.44, 0.56, 0.90), n.y * 0.5 + 0.5);
                float rim = pow(1.0 - max(dot(n, V), 0.0), 3.0);
                vec3 H = normalize(L + V);
                float spec = pow(max(dot(n, H), 0.0), 36.0) * 0.32;
                vec3 lc = amb * 0.86 + band * vec3(0.78, 0.68, 0.50) + rim * vec3(0.20, 0.28, 0.42);
                col = col * lc + spec * vec3(1.0, 0.96, 0.86);
            }
            vC = vec4(col, aC.a);
            vFog = clamp((gl_Position.w - 1900.0) / 3200.0, 0.0, 1.0);
        }
    """.trimIndent()

    private val FS = """
        precision mediump float;
        uniform vec3 uFog;
        varying vec4 vC;
        varying float vFog;
        varying float vLit;
        void main() {
            vec3 c = mix(vC.rgb * mix(1.0, 0.7, vLit), uFog, vFog);
            float lum = dot(c, vec3(0.299, 0.587, 0.114));
            c = mix(vec3(lum), c, 1.18);
            c = (c - 0.5) * 1.06 + 0.5;
            gl_FragColor = vec4(c, vC.a);
        }
    """.trimIndent()

    /** Fragment shader com textura procedural (neve, pedra, gelo) usada só no cenário estático. */
    private val FS_DETAIL = """
        #ifdef GL_FRAGMENT_PRECISION_HIGH
        precision highp float;
        #else
        precision mediump float;
        #endif
        uniform vec3 uFog;
        uniform float uDet;
        varying vec4 vC;
        varying float vFog;
        varying vec3 vW;
        varying float vLit;
        float h21(vec2 p) {
            vec3 p3 = fract(vec3(p.x, p.y, p.x) * 0.1031);
            p3 += dot(p3, p3.yzx + 33.33);
            return fract((p3.x + p3.y) * p3.z);
        }
        float vn(vec2 p) {
            vec2 i = floor(p);
            vec2 f = fract(p);
            f = f * f * (3.0 - 2.0 * f);
            float a = h21(i);
            float b = h21(i + vec2(1.0, 0.0));
            float c = h21(i + vec2(0.0, 1.0));
            float d = h21(i + vec2(1.0, 1.0));
            return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        void main() {
            vec3 c = vC.rgb;
            if (uDet > 0.5) {
                vec2 q = vW.xz + vW.y * vec2(0.6, 0.35);
                float n1 = vn(q * 0.11);
                float n2 = vn(q * 0.45 + 17.0);
                float n3 = vn(q * 1.7 + 5.0);
                float m = (n1 - 0.5) * 0.15 + (n2 - 0.5) * 0.12 + (n3 - 0.5) * 0.07;
                c *= 1.0 + m;
                float l0 = dot(c, vec3(0.299, 0.587, 0.114));
                float sp = step(0.93, h21(floor(q * 3.1))) * smoothstep(0.62, 0.9, l0);
                c += vec3(0.10, 0.12, 0.16) * sp * (0.5 + 0.5 * n3);
                float ice = smoothstep(0.62, 0.8, n1) * smoothstep(0.55, 0.85, l0);
                c = mix(c, c * vec3(0.90, 0.97, 1.08), ice * 0.5);
            }
            float ex = uDet > 0.5 ? 0.62 : 0.88;
            c *= mix(1.0, ex, vLit);
            c = mix(c, uFog, vFog);
            float lum = dot(c, vec3(0.299, 0.587, 0.114));
            c = mix(vec3(lum), c, 1.22);
            c = (c - 0.5) * 1.10 + 0.5;
            gl_FragColor = vec4(c, vC.a);
        }
    """.trimIndent()

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader: $log")
        }
        return s
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val vs = shader(GLES20.GL_VERTEX_SHADER, VS)
        val fs = try {
            shader(GLES20.GL_FRAGMENT_SHADER, FS_DETAIL)
        } catch (e: RuntimeException) {
            shader(GLES20.GL_FRAGMENT_SHADER, FS)
        }
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        uVP = GLES20.glGetUniformLocation(prog, "uVP")
        uFog = GLES20.glGetUniformLocation(prog, "uFog")
        uCam = GLES20.glGetUniformLocation(prog, "uCam")
        uOut = GLES20.glGetUniformLocation(prog, "uOut")
        uDet = GLES20.glGetUniformLocation(prog, "uDet")
        aP = GLES20.glGetAttribLocation(prog, "aP")
        aN = GLES20.glGetAttribLocation(prog, "aN")
        aC = GLES20.glGetAttribLocation(prog, "aC")
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        dynVbo = ids[0]
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glClearColor(SKY_R, SKY_G, SKY_B, 1f)
        statics.clear()
        synchronized(g.lock) {
            g.scene.buildStatic(this)
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        GLES20.glEnableVertexAttribArray(aP)

        GLES20.glEnableVertexAttribArray(aN)
        GLES20.glEnableVertexAttribArray(aC)
        // só montar a cena fica sob a trava; o desenho na GPU roda livre
        val b = synchronized(g.lock) {
            GLES20.glUniformMatrix4fv(uVP, 1, false, g.vp, 0)
            GLES20.glUniform3f(uFog, SKY_R, SKY_G, SKY_B)
            GLES20.glUniform3f(uCam, g.camPos[0], g.camPos[1], g.camPos[2])
            GLES20.glUniform1f(uOut, 0f)
            g.scene.frame()
        }
        val cx = g.camX
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glUniform1f(uDet, 1f)
        for (s in statics) {
            if (s.x1 < cx - 3000f || s.x0 > cx + 3000f) continue
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, s.vbo)
            attribs()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, s.count)
        }
        GLES20.glUniform1f(uDet, 0f)
        if (b.opq.n > 0) {
            upload(b.opq)
            GLES20.glUniform1f(uOut, 1.9f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, b.opq.n / 10)
            GLES20.glUniform1f(uOut, 0f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, b.opq.n / 10)
        }
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glDepthMask(false)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        drawBuf(b.alp)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE)
        drawBuf(b.add)

        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun attribs() {
        GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 40, 0)
        GLES20.glVertexAttribPointer(aN, 3, GLES20.GL_FLOAT, false, 40, 12)
        GLES20.glVertexAttribPointer(aC, 4, GLES20.GL_FLOAT, false, 40, 24)
    }

    private fun drawBuf(b: VBuf) {
        if (b.n <= 0) return
        upload(b)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, b.n / 10)
    }

    private fun upload(b: VBuf) {
        if (fb.capacity() < b.n) {
            fb = ByteBuffer.allocateDirect(4 * (b.n + 20000)).order(ByteOrder.nativeOrder()).asFloatBuffer()
        }
        fb.clear()
        fb.put(b.v, 0, b.n)
        fb.position(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, dynVbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, b.n * 4, fb, GLES20.GL_STREAM_DRAW)
        attribs()
    }

    /** Envia um lote estático (terreno, árvores) para a GPU. */
    fun uploadStatic(b: Batch, x0: Float, x1: Float) {
        val buf = b.opq
        if (buf.n <= 0) return
        val f = ByteBuffer.allocateDirect(4 * buf.n).order(ByteOrder.nativeOrder()).asFloatBuffer()
        f.put(buf.v, 0, buf.n)
        f.position(0)
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, buf.n * 4, f, GLES20.GL_STATIC_DRAW)
        statics.add(StaticMesh(ids[0], buf.n / 10, x0, x1))
    }
}
